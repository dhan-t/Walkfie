package com.example.walkfie;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    TextView displayName, displayEmail, displayPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        displayName = findViewById(R.id.displayName);
        displayEmail = findViewById(R.id.displayEmail);
        displayPassword = findViewById(R.id.displayPassword);

        SharedPreferences sharedPref = getSharedPreferences("UserData", MODE_PRIVATE);
        String firstName = sharedPref.getString("firstName", "");
        String lastName = sharedPref.getString("lastName", "");
        String email = sharedPref.getString("email", "");
        String password = sharedPref.getString("password", "");

        displayName.setText("Name: " + firstName + " " + lastName);
        displayEmail.setText("Email: " + email);
        displayPassword.setText("Password: " + password);
    }
}
