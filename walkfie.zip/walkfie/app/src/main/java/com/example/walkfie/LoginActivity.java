package com.example.walkfie;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    EditText emailInput, passwordInput;
    Button loginButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginButton);

        loginButton.setOnClickListener(v -> {
            SharedPreferences sharedPref = getSharedPreferences("UserData", MODE_PRIVATE);
            String savedEmail = sharedPref.getString("email", "");
            String savedPassword = sharedPref.getString("password", "");

            String inputEmail = emailInput.getText().toString();
            String inputPassword = passwordInput.getText().toString();

            if (inputEmail.equals(savedEmail) && inputPassword.equals(savedPassword)) {
                startActivity(new Intent(LoginActivity.this, HomeActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Invalid email or password", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
